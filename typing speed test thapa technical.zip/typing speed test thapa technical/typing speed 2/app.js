
const setWord=["This is typing speed App",
                "We can test speed through this App",
                "It helps us to examine ourself"
            
            ]
const myMsg=document.getElementById("showMsg");
const testSpeed=document.getElementById("typeWord");
const btn=document.getElementById("btn");
let startTime,endTime;

  const playGame=()=>{
let randomNumber=Math.floor(Math.random()*setWord.length)
myMsg.innerText=setWord[randomNumber];
let date=new Date();
startTime=date.getTime();
btn.innerText="Done";

}

let endPlay=()=>{
    let date=new Date();
     endTime=date.getTime();
    let totalTime=((endTime-startTime)/1000);
    let totalStr=testSpeed.value;
    let wordCount=wordCounter(totalStr);
    let speed=Math.floor((wordCount/totalTime)*60);
    let finalMsg="your typed total"+speed+"word per minute";
    finalMsg+=compareWords(showMsg.innerText,totalStr);
    showMsg.innerText=finalMsg;

}


/*
let endPlay =()=>{

    let date = new Date();
    endTime=date.getTime();
    let totalTime=((endTime-startTime)/1000);

    let totalStr =typeWords.value;
    let wordCount =wordCounter(totalStr);
    
    let speed  = Math.floor((wordCount/totalTime) * 60);

    let finalMsg= "You typed total "+speed+" word per minutes";
    finalMsg+=compareWords(msg.innerText,totalStr);
    msg.innerText=finalMsg;

}*/





const compareWords=(str1,str2)=>{

    let words1=str1.split(" ");
    let words2=str2.split(" ");
    let cnt=0;

    words1.forEach(function(item,index){
        if(item==words2[index]){
            cnt++;
        }

    });


    let errorWords=(words1.length-cnt);
    return(cnt+"correct out of "+words1.length+"words the total number of the error are "+errorWords+".");
}
const wordCounter =(str)=>{

    let response =str.split(" ").length;
    return response;
};


btn.addEventListener("click",function(){

if(this.innerText=="Start"){
    testSpeed.disabled=false;
    playGame();

}else if (this.innerText="Done"){
    testSpeed.disabled=true;
    btn.innerText="Start";
    endPlay();
};

})
/*
const wordCounter =(str)=>{

    let response =str.split(" ").length;
    return response;
    
    
    }
    

*/


/*


/*
 
btn.addEventListener("click", function(){

    if(this.innerText=="Start"){
        typeWords.disabled=false;
        playGame();
    }else if (this.innerText=="Done") {
            typeWords.disabled=true;
            btn.innerText="Start";
            endPlay();
    
    }
    })
    */
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	